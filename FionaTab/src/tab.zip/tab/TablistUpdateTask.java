package tab;

import cc.funkemunky.Meme.Tab;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class TablistUpdateTask implements Runnable {
	
    @SuppressWarnings("deprecation")
	@Override
    public void run() {
        TablistManager manager = Tab.getInstance().getTabHandler();
        if(manager == null) {
            return;
        }
        Tablist tablist;
        for(Player all : Bukkit.getServer().getOnlinePlayers()) {
        	tablist = manager.getTablist(all);
            if(tablist != null) {
                tablist.hideRealPlayers().update();
            }
        }
    }
}
