package tab.reflection;

import java.util.Map;
import java.util.UUID;

import net.minecraft.server.v1_7_R4.EnumProtocol;

public class ReflectionConstants {
	
    public static Class<?> TAB_PACKET_CLASS = Reflection.getMinecraftClass("PacketPlayOutPlayerInfo");
    public static Reflection.ConstructorInvoker TAB_PACKET_CONSTRUCTOR = Reflection.getConstructor(ReflectionConstants.TAB_PACKET_CLASS, (Class<?>[])new Class[0]);
    public static Reflection.FieldAccessor<Integer> TAB_PACKET_ACTION = Reflection.getField(ReflectionConstants.TAB_PACKET_CLASS, Integer.TYPE, 5);
    public static Reflection.FieldAccessor<String> TAB_PACKET_NAME = Reflection.getField(ReflectionConstants.TAB_PACKET_CLASS, String.class, 0);
    public static Class<Object> GAME_PROFILE_CLASS = getUntypedClasses("net.minecraft.util.com.mojang.authlib.GameProfile", "com.mojang.authlib.GameProfile");
    public static Reflection.ConstructorInvoker GAME_PROFILE_CONSTRUCTOR = Reflection.getConstructor(ReflectionConstants.GAME_PROFILE_CLASS, UUID.class, String.class);
    public static Reflection.FieldAccessor<String> GAME_PROFILE_NAME = Reflection.getField(ReflectionConstants.GAME_PROFILE_CLASS, String.class, 0);
    public static Reflection.FieldAccessor<Object> TAB_PACKET_PROFILE = Reflection.getField(ReflectionConstants.TAB_PACKET_CLASS, ReflectionConstants.GAME_PROFILE_CLASS, 0);
    public static Class<?> CRAFT_PLAYER_CLASS = Reflection.getCraftBukkitClass("entity.CraftPlayer");
    public static Class<?> NMS_PACKET_CLASS = Reflection.getMinecraftClass("Packet");
    public static Class<?> NMS_PLAYER_CLASS = Reflection.getMinecraftClass("EntityPlayer");
    public static Class<?> PLAYER_CONNECTION_CLASS = Reflection.getMinecraftClass("PlayerConnection");
    public static Class<?> NETWORK_MANAGER_CLASS = Reflection.getMinecraftClass("NetworkManager");
    public static Reflection.MethodInvoker GET_HANDLE_METHOD = Reflection.getMethod(ReflectionConstants.CRAFT_PLAYER_CLASS, "getHandle", (Class<?>[])new Class[0]);
    public static Reflection.MethodInvoker GET_PROFILE_METHOD = Reflection.getMethod(ReflectionConstants.CRAFT_PLAYER_CLASS, "getProfile", (Class<?>[])new Class[0]);
    public static Reflection.MethodInvoker VERSION_METHOD = Reflection.getMethod(ReflectionConstants.NETWORK_MANAGER_CLASS, "getVersion", (Class<?>[])new Class[0]);
    public static Reflection.MethodInvoker SEND_PACKET = Reflection.getMethod(ReflectionConstants.PLAYER_CONNECTION_CLASS, "sendPacket", ReflectionConstants.NMS_PACKET_CLASS);
    public static Reflection.FieldAccessor<?> PLAYER_CONNECTION = Reflection.getField(ReflectionConstants.NMS_PLAYER_CLASS, ReflectionConstants.PLAYER_CONNECTION_CLASS, 0);
    public static Reflection.FieldAccessor<?> NETWORK_MANAGER = Reflection.getField(ReflectionConstants.PLAYER_CONNECTION_CLASS, ReflectionConstants.NETWORK_MANAGER_CLASS, 0);
    public static Class<?> ENUM_PROTOCOL_CLASS = Reflection.getMinecraftClass("EnumProtocol");
    public static Reflection.FieldAccessor<?> ENUM_PROTOCOL_PLAY = Reflection.getField(ReflectionConstants.ENUM_PROTOCOL_CLASS, ReflectionConstants.ENUM_PROTOCOL_CLASS, 1);;
    @SuppressWarnings("rawtypes")
	public static Reflection.FieldAccessor<Map> ENUM_PROTOCOL_REGISTRY = Reflection.getField(ReflectionConstants.ENUM_PROTOCOL_CLASS, Map.class, 0);
    
    public static Class<Object> getUntypedClasses(String... lookupNames) {
        EnumProtocol.class.getName();
        for(String s : lookupNames) {
        	try {
                return Reflection.getUntypedClass(s);
            }
            catch (IllegalArgumentException e) {
                continue;
            }
        }
        throw new IllegalArgumentException("No class found in selection given");
    }
}
