package tab.reflection;

import org.bukkit.Bukkit;
import java.util.regex.Matcher;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.lang.reflect.Field;
import java.util.regex.Pattern;

public class Reflection {
	
    private static String OBC_PREFIX = Bukkit.getServer().getClass().getPackage().getName();
    private static String NMS_PREFIX = Reflection.OBC_PREFIX.replace("org.bukkit.craftbukkit", "net.minecraft.server");
    private static String VERSION = Reflection.OBC_PREFIX.replace("org.bukkit.craftbukkit", "").replace(".", "");
    private static Pattern MATCH_VARIABLE = Pattern.compile("\\{([^\\}]+)\\}");
    
    public static <T> FieldAccessor<T> getField(Class<?> clazz, String s, Class<T> clazz2) {
        return getField(clazz, s, clazz2, 0);
    }
    
    public static <T> FieldAccessor<T> getField(String s, String s2, Class<T> clazz) {
        return getField(getClass(s), s2, clazz, 0);
    }
    
    public static <T> FieldAccessor<T> getField(Class<?> clazz, Class<T> clazz2, int n) {
        return getField(clazz, null, clazz2, n);
    }
    
    public static <T> FieldAccessor<T> getField(String s, Class<T> clazz, int n) {
        return getField(getClass(s), clazz, n);
    }
    
    private static <T> FieldAccessor<T> getField(Class<?> clazz, String s, Class<T> clazz2, int n) {
        for(Field field : clazz.getDeclaredFields()) {
            if((s == null || field.getName().equals(s)) && clazz2.isAssignableFrom(field.getType()) && n-- <= 0) {
                field.setAccessible(true);
                return new FieldAccessor<T>() {
                    @SuppressWarnings("unchecked")
					@Override
                    public T get(Object o) {
                        try {
                            return (T)field.get(o);
                        }
                        catch (IllegalAccessException ex) {
                            throw new RuntimeException("Cannot access reflection.", ex);
                        }
                    }
                    
                    @Override
                    public void set(Object o, Object o2) {
                        try {
                            field.set(o, o2);
                        }
                        catch (IllegalAccessException ex) {
                            throw new RuntimeException("Cannot access reflection.", ex);
                        }
                    }
                    
                    @Override
                    public boolean hasField(Object o) {
                        return field.getDeclaringClass().isAssignableFrom(o.getClass());
                    }
                };
            }
        }
        if(clazz.getSuperclass() != null) {
            return getField(clazz.getSuperclass(), s, clazz2, n);
        }
        throw new IllegalArgumentException("Cannot find field with type " + clazz2);
    }
    
    public static MethodInvoker getMethod(String s, String s2, Class<?>... array) {
        return getTypedMethod(getClass(s), s2, null, array);
    }
    
    public static MethodInvoker getMethod(Class<?> clazz, String s, Class<?>... array) {
        return getTypedMethod(clazz, s, null, array);
    }
    
    public static MethodInvoker getTypedMethod(Class<?> clazz, String s, Class<?> clazz2, Class<?>... array) {
        for(Method method : clazz.getDeclaredMethods()) {
            if((s == null || method.getName().equals(s)) && (clazz2 == null || method.getReturnType().equals(clazz2)) && Arrays.equals(method.getParameterTypes(), array)) {
                method.setAccessible(true);
                return new MethodInvoker() {
                    @Override
                    public Object invoke(Object o, Object... array) {
                        try {
                            return method.invoke(o, array);
                        }
                        catch(Exception ex) {
                            throw new RuntimeException("Cannot invoke method " + method, ex);
                        }
                    }
                };
            }
        }
        if(clazz.getSuperclass() != null) {
            return getMethod(clazz.getSuperclass(), s, array);
        }
        throw new IllegalStateException(String.format("Unable to find method %s (%s).", s, Arrays.asList(array)));
    }
    
    public static ConstructorInvoker getConstructor(String s, Class<?>... array) {
        return getConstructor(getClass(s), array);
    }
    
    public static ConstructorInvoker getConstructor(Class<?> clazz, Class<?>... array) {
        for(Constructor<?> constructor : clazz.getDeclaredConstructors()) {
            if(Arrays.equals(constructor.getParameterTypes(), array)) {
                constructor.setAccessible(true);
                return new ConstructorInvoker() {
                    @Override
                    public Object invoke(Object... array) {
                        try {
                            return constructor.newInstance(array);
                        }
                        catch (Exception ex) {
                            throw new RuntimeException("Cannot invoke constructor " + constructor, ex);
                        }
                    }
                };
            }
        }
        throw new IllegalStateException(String.format("Unable to find constructor for %s (%s).", clazz, Arrays.asList(array)));
    }
    
    @SuppressWarnings("unchecked")
	public static Class<Object> getUntypedClass(String s) {
        return (Class<Object>) getClass(s);
    }
    
    public static Class<?> getClass(String s) {
        return getCanonicalClass(expandVariables(s));
    }
    
    public static Class<?> getMinecraftClass(String s) {
        return getCanonicalClass(Reflection.NMS_PREFIX + "." + s);
    }
    
    public static Class<?> getCraftBukkitClass(String s) {
        return getCanonicalClass(Reflection.OBC_PREFIX + "." + s);
    }
    
    private static Class<?> getCanonicalClass(String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException ex) {
            throw new IllegalArgumentException("Cannot find " + s, ex);
        }
    }
    
    private static String expandVariables(String s) {
        StringBuffer sb = new StringBuffer();
        Matcher matcher = Reflection.MATCH_VARIABLE.matcher(s);
        while(matcher.find()) {
            String group = matcher.group(1);
            String s2;
            if ("nms".equalsIgnoreCase(group)) {
                s2 = Reflection.NMS_PREFIX;
            }
            else if ("obc".equalsIgnoreCase(group)) {
                s2 = Reflection.OBC_PREFIX;
            }
            else {
                if (!"version".equalsIgnoreCase(group)) {
                    throw new IllegalArgumentException("Unknown variable: " + group);
                }
                s2 = Reflection.VERSION;
            }
            if (s2.length() > 0 && matcher.end() < s.length() && s.charAt(matcher.end()) != '.') {
                s2 += ".";
            }
            matcher.appendReplacement(sb, Matcher.quoteReplacement(s2));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }
    
    public interface FieldAccessor<T> {
        T get(Object p0);
        
        void set(Object p0, Object p1);
        
        boolean hasField(Object p0);
    }
    
    public interface MethodInvoker {
        Object invoke(Object p0, Object... p1);
    }
    
    public interface ConstructorInvoker {
        Object invoke(Object... p0);
    }
}
