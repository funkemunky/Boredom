package tab;

import cc.funkemunky.Meme.Tab;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.PluginDisableEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class TablistManager implements Listener {
	
    private Map<UUID, Tablist> tablists;
    private @Getter TablistEntrySupplier supplier;
    private int updateTaskId;
    
    @SuppressWarnings("deprecation")
	public TablistManager(TablistEntrySupplier supplier, long updateTime) {
        this.updateTaskId = -1;
        long remainder = updateTime % 50L;
        if(remainder != 0L) {
            updateTime -= remainder;
            Bukkit.getLogger().info("FIXING UPDATE TIME TO VALID TICK-COUNT...");
        }
        this.tablists = new ConcurrentHashMap<UUID, Tablist>();
        this.supplier = supplier;
        this.updateTaskId = Bukkit.getScheduler().runTaskTimerAsynchronously(Tab.getInstance(), new TablistUpdateTask(), updateTime / 50L, updateTime / 50L).getTaskId();
        Bukkit.getPluginManager().registerEvents(this, Tab.getInstance());
        for(Player all : Bukkit.getServer().getOnlinePlayers()) {
        	this.getTablist(all, true);
        }
    }

    public Map<UUID, Tablist> getTablists() {
        return tablists;
    }

    public void setTablists(Map<UUID, Tablist> tablists) {
        this.tablists = tablists;
    }

    public TablistEntrySupplier getSupplier() {
        return supplier;
    }

    public void setSupplier(TablistEntrySupplier supplier) {
        this.supplier = supplier;
    }

    @Deprecated
    public Tablist getTablist(Player p) {
        return this.getTablist(p, false);
    }
    
    @Deprecated
    public Tablist getTablist(Player p, boolean create) {
        Tablist tablist = this.tablists.get(p.getUniqueId());
        if(tablist == null && create) {
            this.tablists.put(p.getUniqueId(), tablist = new Tablist(p));
        }
        return tablist;
    }
    
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if(Tab.getInstance().getTabPlayer(p)) {
            getTablist(p, true);
        }
    }
    
    @EventHandler
    public void onDisable(PluginDisableEvent e) {
        if(e.getPlugin() == Tab.getInstance()) {
            this.tablists.forEach((id, tablist) -> tablist.hideFakePlayers().clear());
            this.tablists.clear();
            HandlerList.unregisterAll(this);
            if(this.updateTaskId != -1) {
                Bukkit.getScheduler().cancelTask(this.updateTaskId);
            }
        }
    }
    
    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        Tablist tablist;
        if((tablist = this.tablists.remove(p.getUniqueId())) != null) {
            tablist.hideFakePlayers().clear();
        }
    }
}
