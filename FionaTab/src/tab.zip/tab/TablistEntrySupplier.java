package tab;

import com.google.common.collect.Table;
import org.bukkit.entity.Player;

public interface TablistEntrySupplier {
	
    Table<Integer, Integer, String> getEntries(Player p0);
    
    String getHeader(Player p0);
    
    String getFooter(Player p0);
}